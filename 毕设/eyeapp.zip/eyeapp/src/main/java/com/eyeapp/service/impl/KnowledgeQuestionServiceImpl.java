package com.eyeapp.service.impl;

import com.eyeapp.common.ServerResponse;
import com.eyeapp.dao.KnowledgeQuestionMapper;
import com.eyeapp.pojo.KnowledgeQuestion;
import com.eyeapp.service.IKnowledgeQuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2017/12/27 0027.
 */
@Service("iKnowledgeQuestionService")
public class KnowledgeQuestionServiceImpl implements IKnowledgeQuestionService{

    @Autowired
    private KnowledgeQuestionMapper knowledgeQuestionMapper;

    @Override
    public ServerResponse saveOrUpdateKnowledgeQuestion(KnowledgeQuestion knowledgeQuestion) {
         if(knowledgeQuestion!=null){
            if(knowledgeQuestion.getId()!=null){
                int rowcount = knowledgeQuestionMapper.updateByPrimaryKey(knowledgeQuestion);
                if(rowcount>0){
                    return ServerResponse.createBySuccess("更新成功");
                }else {
                    return ServerResponse.createByErrorMessage("更新失败");
                }
            }else {
                int rowcount = knowledgeQuestionMapper.insert(knowledgeQuestion);
                if(rowcount>0){
                    return ServerResponse.createBySuccess("更新成功");
                }else {
                    return ServerResponse.createByErrorMessage("更新失败");
                }
            }
         }else {
             return ServerResponse.createByErrorMessage("新增或更新不成功，参数不正确");
         }
    }
}
