package com.eyeapp.dao;

import com.eyeapp.pojo.KnowledgeQuestion;

public interface KnowledgeQuestionMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(KnowledgeQuestion record);

    int insertSelective(KnowledgeQuestion record);

    KnowledgeQuestion selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(KnowledgeQuestion record);

    int updateByPrimaryKey(KnowledgeQuestion record);
}