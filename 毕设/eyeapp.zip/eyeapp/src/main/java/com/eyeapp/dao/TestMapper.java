package com.eyeapp.dao;

import com.eyeapp.pojo.Test;

public interface TestMapper {

    int submitresult(Test record);

}