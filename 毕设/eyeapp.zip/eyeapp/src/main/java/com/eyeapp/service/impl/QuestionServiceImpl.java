package com.eyeapp.service.impl;

import com.eyeapp.common.ServerResponse;
import com.eyeapp.dao.QuestionMapper;
import com.eyeapp.dao.TestMapper;
import com.eyeapp.pojo.Question;
import com.eyeapp.pojo.Test;
import com.eyeapp.service.IQuestionService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by Administrator on 2017/12/27 0027.
 */
@Service("iQuestionService")
public class QuestionServiceImpl implements IQuestionService{

    @Autowired
    private QuestionMapper questionMapper ;

    @Autowired
    private TestMapper testMapper ;

    /**
     * 随机抽取某种类型的题n题
     * @param questionsize
     * @param type
     * @return
     */
    @Override
    public ServerResponse<List<Question>> getRandomQuestionByType(Integer questionsize, String type) {
        List<Question> list = questionMapper.selectRandomList(questionsize,type);
        return ServerResponse.createBySuccess(list);
    }

    /**
     * 提交测试结果
     * @param test
     * @return
     */
    @Override
    public ServerResponse submitQuestionResult(Test test){

        if(StringUtils.isBlank(test.getType())||test.getCorrectRate()==null||test.getTestResult()==null){
            return ServerResponse.createByErrorMessage("提交的信息有误！");
        }
        int rowCount = testMapper.submitresult(test);
        if(rowCount>0){
            return ServerResponse.createBySuccess("提交结果成功");
        }
        return ServerResponse.createByErrorMessage("提交测试结果不成功");

    }
}
