package com.eyeapp.controller;

import com.eyeapp.common.Const;
import com.eyeapp.common.ResponseCode;
import com.eyeapp.common.ServerResponse;
import com.eyeapp.pojo.KnowledgeQuestion;
import com.eyeapp.pojo.User;
import com.eyeapp.service.IKnowledgeQuestionService;
import com.eyeapp.service.IKnowledgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;

/**
 * Created by Administrator on 2017/12/25 0025.
 */
@Controller
@RequestMapping(value = "/knowledge")
public class KnowledgeController {
    @Autowired
    private IKnowledgeService iKnowledgeService ;

    @Autowired
    private IKnowledgeQuestionService iKnowledgeQuestionService;

    /**
     * 文章列表
     * @param pageNum
     * @param pageSize
     * @param type
     * @return
     */
    @RequestMapping("list.do")
    @ResponseBody
    public ServerResponse getList(@RequestParam(value = "pageNum",defaultValue = "1") int pageNum, @RequestParam(value = "pageSize",defaultValue = "10") int pageSize,@RequestParam(value = "type",defaultValue = "") String type){
        return iKnowledgeService.getKnowledgePaperList(pageNum,pageSize,type);
    }

    /**
     * 热门文章
     * @param pageNum
     * @param pageSize
     * @return
     */
    @RequestMapping("hotlist.do")
    @ResponseBody
    public ServerResponse getHotPaperList(@RequestParam(value = "pageNum",defaultValue = "1") int pageNum, @RequestParam(value = "pageSize",defaultValue = "5") int pageSize){
        return  iKnowledgeService.getKnowledgeHotPaperList(pageNum,pageSize);
    }

    /**
     * 根据id获取文章
     * @param id
     * @return
     */
    @RequestMapping("detail.do")
    @ResponseBody
    public ServerResponse getPaperById(Integer id){
        return  iKnowledgeService.getKnowledgePaperById(id);
    }


    @RequestMapping(value = "askquestion.do" ,method = RequestMethod.POST)
    @ResponseBody
    public ServerResponse askQuestion(HttpSession session, KnowledgeQuestion knowledgeQuestion){
        User user = (User)session.getAttribute(Const.CURRENT_USER);
        if(user == null){
            return ServerResponse.createByErrorCodeMessage(ResponseCode.NEED_LOGIN.getCode(),"用户未登录,请登录管理员");

        }
        knowledgeQuestion.setuId(user.getId());
        return ServerResponse.createBySuccess(iKnowledgeQuestionService.saveOrUpdateKnowledgeQuestion(knowledgeQuestion));
    }
}
