package com.eyeapp.controller;

import com.eyeapp.common.Const;
import com.eyeapp.common.ResponseCode;
import com.eyeapp.common.ServerResponse;
import com.eyeapp.pojo.Test;
import com.eyeapp.pojo.User;
import com.eyeapp.service.IQuestionService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Created by Administrator on 2017/12/27 0027.
 */
@Controller
@RequestMapping(value = "/eyetest")
public class QuestionController {

    @Autowired
    private IQuestionService iQuestionService;

    /**
     * 随机抽取n题某种类型的题目
     * @param questionsize
     * @param type
     * @return
     */
    @RequestMapping("randomquestion.do")
    @ResponseBody
    public ServerResponse getRandomQuestionByType(@RequestParam(value = "questionsize",defaultValue = "5") int questionsize, @RequestParam(value = "type") String type){
        return  iQuestionService.getRandomQuestionByType(questionsize,type);
    }

    /**
     * 提交测试结果
     * @param httpSession
     * @param test
     * @return
     */
    @RequestMapping(value = "submitquestion.do" ,method = RequestMethod.POST)
    @ResponseBody
    public ServerResponse submitQuestionResult(HttpServletRequest httpServletRequest, Test test){
        Cookie[] cookies = httpServletRequest.getCookies();
        if(cookies!=null){
            for (Cookie cookie:cookies){
                if (cookie.getName().equals("sso_token")){
                    if(jedisUtil.exist(USER_FORWARD_CACHE_PREFIX,cookie.getValue())){
                        return true;
                    }
                }
            }
        }
        test.setuId(user.getId());
        return iQuestionService.submitQuestionResult(test);
    }
}
