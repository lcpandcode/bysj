package com.eyeapp.controller;

import com.eyeapp.common.Const;
import com.eyeapp.common.ServerResponse;
import com.eyeapp.pojo.User;
import com.eyeapp.service.IUserService;
import com.eyeapp.util.RedisUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import redis.clients.jedis.Jedis;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.UUID;

/**
 * Created by Administrator on 2018/1/7 0007.
 */
@Controller
@RequestMapping(value = "/user")
public class UserController {
    public static int cookie_age = 3600*24*3;
    @Autowired
    private IUserService iUserService ;

    /**
     * 用户登录
     * @param phone
     * @param password
     * @param session
     * @return
     */
    @RequestMapping(value = "login.do" ,method = RequestMethod.POST)
    @ResponseBody
    public ServerResponse<User> login(String phone , String password , HttpSession session, HttpServletRequest req, HttpServletResponse res){

        ServerResponse<User> response = iUserService.login(phone,password);
        if(response.isSuccess()){
            String uuid = UUID.randomUUID().toString().replaceAll("\\-", "");
            Cookie cookie = new Cookie("token",uuid);
            cookie.setPath("/");
            cookie.setMaxAge(cookie_age);
            res.addCookie(cookie);
            RedisUtil.setex(uuid,phone,cookie_age);
        }
        return response;
    }
}
