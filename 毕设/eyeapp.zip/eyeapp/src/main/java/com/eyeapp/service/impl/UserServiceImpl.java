package com.eyeapp.service.impl;

import com.eyeapp.common.ServerResponse;
import com.eyeapp.dao.UserMapper;
import com.eyeapp.pojo.User;
import com.eyeapp.service.IUserService;
import com.eyeapp.util.MD5Util;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2018/1/7 0007.
 */
@Service("iUserService")
public class UserServiceImpl implements IUserService{


    @Autowired
    private UserMapper userMapper ;


    @Override
    public ServerResponse<User> login(String phone, String password) {
        int rowCount = userMapper.checkPhone(phone);
        if(rowCount==0){
            //不存在这个手机
            return  ServerResponse.createByErrorMessage("用户不存在");
        }
        //todo 密码登录MD5
        String md5password = MD5Util.MD5EncodeUtf8(password);

        User user = userMapper.selectLogin(phone,md5password);

        if(user==null){
            return  ServerResponse.createByErrorMessage("密码错误");
        }

        user.setPassword(StringUtils.EMPTY);

        return ServerResponse.createBySuccess("登录成功",user);
    }
}
