package com.eyeapp.service;

import com.eyeapp.common.ServerResponse;
import com.eyeapp.pojo.KnowledgePaper;
import com.github.pagehelper.PageInfo;

/**
 * Created by Administrator on 2017/12/25 0025.
 */
public interface IKnowledgeService {

    ServerResponse<PageInfo> getKnowledgePaperList(int pageNum, int pageSize,String type);

    ServerResponse getKnowledgeHotPaperList(int pageNum, int pageSize);

    ServerResponse<KnowledgePaper> getKnowledgePaperById(Integer id);

}
