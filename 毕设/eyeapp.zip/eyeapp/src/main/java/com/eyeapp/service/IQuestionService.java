package com.eyeapp.service;

import com.eyeapp.common.ServerResponse;
import com.eyeapp.pojo.Question;
import com.eyeapp.pojo.Test;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * Created by Administrator on 2017/12/27 0027.
 */
public interface IQuestionService {
    ServerResponse<List<Question>> getRandomQuestionByType(Integer questionsize, String type);

    ServerResponse submitQuestionResult(Test test);
}
