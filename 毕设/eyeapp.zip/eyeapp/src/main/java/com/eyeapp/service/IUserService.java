package com.eyeapp.service;

import com.eyeapp.common.ServerResponse;
import com.eyeapp.pojo.User;

/**
 * Created by Administrator on 2018/1/7 0007.
 */
public interface IUserService {
    ServerResponse<User> login(String phone, String password);

}
