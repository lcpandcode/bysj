package com.eyeapp.service;

import com.eyeapp.common.ServerResponse;
import com.eyeapp.pojo.KnowledgeQuestion;

/**
 * Created by Administrator on 2017/12/27 0027.
 */
public interface IKnowledgeQuestionService {
    ServerResponse saveOrUpdateKnowledgeQuestion(KnowledgeQuestion knowledgeQuestion);

}
