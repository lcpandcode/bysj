package com.eyeapp.service.impl;

import com.eyeapp.common.ResponseCode;
import com.eyeapp.common.ServerResponse;
import com.eyeapp.dao.KnowledgePaperMapper;
import com.eyeapp.pojo.KnowledgePaper;
import com.eyeapp.service.IKnowledgeService;
import com.eyeapp.vo.KnowledgeListVo;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by Administrator on 2017/12/25 0025.
 */
@Service("iKnowledgeService")
public class KnowledgeServiceImpl implements IKnowledgeService {

    @Autowired
    private KnowledgePaperMapper knowledgePaperMapper ;

    /**
     * 获取热文
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public ServerResponse<PageInfo> getKnowledgeHotPaperList(int pageNum, int pageSize){
        PageHelper.startPage(pageNum,pageSize);
        List<KnowledgePaper> list = knowledgePaperMapper.selectHotList();
        PageInfo pageResult = new PageInfo(list);
        pageResult.setList(list);
        return ServerResponse.createBySuccess(pageResult);
    }

    /**
     * 根据id查询文章具体内容
     * @param id
     * @return
     */
    @Override
    public ServerResponse<KnowledgePaper>  getKnowledgePaperById(Integer id) {
        if(id==null){
            return ServerResponse.createByErrorCodeMessage(ResponseCode.ILLEGAL_ARGUMENT.getCode(),ResponseCode.ILLEGAL_ARGUMENT.getDesc());
        }
        KnowledgePaper knowledgePaper =  knowledgePaperMapper.selectByPrimaryKey(id);
        if(knowledgePaper==null){
            return ServerResponse.createByErrorMessage("找不到相应的文章");
        }
        return ServerResponse.createBySuccess(knowledgePaper);
    }


    /**
     * 获取文章列表
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public ServerResponse<PageInfo> getKnowledgePaperList(int pageNum, int pageSize,String type) {
        //startPage--start
        //填充自己的sql查询逻辑
        //pageHelper-收尾
        PageHelper.startPage(pageNum,pageSize);
        List<KnowledgePaper> knowledgePaperList = null ;
        if(type==null||"".equals(type)){
            knowledgePaperList = knowledgePaperMapper.selectList();
        }else{
            int type_num = knowledgePaperMapper.checkPaperTypeExist(type);
            if(type_num>0){
                //如传入了type参数而且有对应的数据，则查该类型的列表
                knowledgePaperList = knowledgePaperMapper.selectListByType(type);
            }else{
                knowledgePaperList = knowledgePaperMapper.selectList();
            }
        }
        List<KnowledgeListVo> knowledgeListVoList = Lists.newArrayList();
        for(KnowledgePaper item : knowledgePaperList){
            KnowledgeListVo knowledgeListVo = assembleProductListVo(item);
            knowledgeListVoList.add(knowledgeListVo);
        }
        PageInfo pageResult = new PageInfo(knowledgePaperList);
        pageResult.setList(knowledgeListVoList);
        return ServerResponse.createBySuccess(pageResult);
    }

    private KnowledgeListVo assembleProductListVo(KnowledgePaper knowledgePaper){
        KnowledgeListVo vo = new KnowledgeListVo();
        vo.setContent(knowledgePaper.getContent());
        vo.setDate(knowledgePaper.getDate());
        vo.setId(knowledgePaper.getId());
        vo.setTitle(knowledgePaper.getTitle());
        vo.setType(knowledgePaper.getType());
        vo.setViewCount(knowledgePaper.getViewCount());
        return vo;
    }
}
