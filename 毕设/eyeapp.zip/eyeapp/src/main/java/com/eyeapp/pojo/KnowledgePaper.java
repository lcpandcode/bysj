package com.eyeapp.pojo;

import java.util.Date;

public class KnowledgePaper {
    private Integer id;

    private String title;

    private String content;

    private Integer viewCount;

    private Date date;

    private String type;

    public KnowledgePaper(Integer id, String title, String content, Integer viewCount, Date date, String type) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.viewCount = viewCount;
        this.date = date;
        this.type = type;
    }

    public KnowledgePaper() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Integer getViewCount() {
        return viewCount;
    }

    public void setViewCount(Integer viewCount) {
        this.viewCount = viewCount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }
}