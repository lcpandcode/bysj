package com.eyeapp.dao;

import com.eyeapp.pojo.KnowledgePaper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface KnowledgePaperMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(KnowledgePaper record);

    int insertSelective(KnowledgePaper record);

    KnowledgePaper selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(KnowledgePaper record);

    int updateByPrimaryKey(KnowledgePaper record);

    List<KnowledgePaper> selectList();

    List<KnowledgePaper> selectHotList();

    List<KnowledgePaper> selectListByType(@Param("type")String type);

    int checkPaperTypeExist(String type);
}