package com.eyeapp.pojo;

import java.util.Date;

public class Message {
    private Integer id;

    private String message;

    private String isRead;

    private Date date;

    private Integer fromId;

    private Integer toId;

    public Message(Integer id, String message, String isRead, Date date, Integer fromId, Integer toId) {
        this.id = id;
        this.message = message;
        this.isRead = isRead;
        this.date = date;
        this.fromId = fromId;
        this.toId = toId;
    }

    public Message() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message == null ? null : message.trim();
    }

    public String getIsRead() {
        return isRead;
    }

    public void setIsRead(String isRead) {
        this.isRead = isRead == null ? null : isRead.trim();
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getFromId() {
        return fromId;
    }

    public void setFromId(Integer fromId) {
        this.fromId = fromId;
    }

    public Integer getToId() {
        return toId;
    }

    public void setToId(Integer toId) {
        this.toId = toId;
    }
}